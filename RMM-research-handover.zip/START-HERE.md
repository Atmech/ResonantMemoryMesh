# Resonant Memory Mesh | Research handover, 19 November 2026

Affan Tanke arrived independently at the question behind this project: what would an AI memory data structure look like if the way memories call up other memories, and the way experience changes those associations, shaped its design? He used AI assistance to develop the prototype and manuscripts. This snapshot is for a collaborator considering taking technical ownership of the research.

## The prototype

Give the program a cue. It looks up similar records, follows weighted links from those starting records, and ranks what the cue activated. A person can supply the links, or the program can create them between similar records. Retrieval changes how active a record is. The proposed next mechanism would also change the links according to which records helped an agent accomplish something. That task-feedback mechanism is a proposal.

## What the evidence supports

In the saved MuSiQue run, 300 questions each came with their own candidate paragraphs. With five chances per question, ordinary vector search retrieved 66.5% of the supporting evidence, averaged over questions. RMM using its automatic links retrieved 62.8%. On the shared entity graph, Personalized PageRank retrieved 60.2% and RMM retrieved 45.2%. The illustrative company-connection demo supplies its links by hand. The evaluation tests retrieval on individual questions. Learning across sessions requires a separate experiment.

Read eval/results.json for the numbers and eval/run_eval.py for how they were produced. The harness rebuilds a graph per question and queries the same mutable mesh successively for different cutoffs. For an independent replication, reset the graph state between cutoffs or obtain the ranking once. Dependencies and datasets must be installed separately.

## Manuscripts and reading order

1. rmm_paper.tex and docs/RMM Reflexivity Loop.tex are historical drafts of the original propagation idea. The 0.36 ms headline in the root draft was withdrawn in the later dossier. The controlled retrieval results above supersede the drafts' broad performance claims.
2. RMM_Mentor_Dossier.md explains the original ambition, what went wrong, and the open questions. RMM_Plastic_Memory_Brief.md lays out the proposed learning experiment. Its claim that other agent memories are static is outdated.
3. For the actual code, begin with Mesh.query, Mesh.ingest and Mesh.connect in rmm-core/rmm/mesh.py, then read rmm-rust/src/kernel.rs. The tests and the local benchmark are included.

## Closest research to compare

HeLa-Mem (ACL 2026) builds a memory graph in which repeated co-activation strengthens associations. This directly overlaps with the proposed biological mechanism. [Published paper](https://aclanthology.org/2026.acl-long.625/)

ExpHarness (October 2026 preprint revision) uses task feedback to update a graph of experiences and measures usefulness by comparing performance with and without retrieved experience. [Preprint](https://arxiv.org/abs/2605.30712)

Anchor (November 2026 preprint) checks individual decisions with and without a candidate memory before retaining it. This bears on how one decides which memory deserves credit. [Preprint](https://arxiv.org/abs/2611.10382)

## First decision for a collaborator

Is there a simple and distinctive experiment worth owning? One candidate is to hold the agent, tasks, retrieval method and memory budget fixed. Compare fixed links, links strengthened whenever records are retrieved together, and links strengthened only when those records helped a successful decision. Evaluate on later, unseen but related tasks. Measure task completion along with the cost of establishing which records helped. If the simple rule gives no consistent advantage, that answers the question too.
