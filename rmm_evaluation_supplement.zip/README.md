# Resonance Is All You Need

Evaluation supplement for Affan Tanke’s manuscript dated 19 November 2026. The discovery sample uses the first 300 eligible MuSiQue validation questions, all two-hop. The follow-up draws 100 two-hop, 100 three-hop and 100 four-hop questions without replacement from later validation rows. Both use the same six retrieval conditions and a depth of five. The paper reports descriptive follow-up means under equal hop weighting.

## Inspect the result

Run python check_tables.py to regenerate both tables from the saved outputs. The two result files are eval/paper_top5.json and eval/paper_balanced.json. The means object contains the three columns of Table 1 as fractions. The paired_intervals object gives a mean difference and its 95% paired bootstrap interval in fractions. Multiply by 100 to read the units used in the paper. Each row contains the MuSiQue question ID, the gold paragraph indices, the retrieved indices for every condition, exact-score tie flags and the metrics. Indices are zero-based within each question. The table labels correspond to cosine, proximity, entity, pagerank, entity_cosine_ties and oracle. The last uses gold labels. The source text and answers remain available from the dataset distributor.

## Rerun the experiment

Use a Python 3.13 environment with a Rust toolchain. From the supplement directory:

    python3 -m venv .venv
    source .venv/bin/activate
    PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1 python -m pip install ./rmm-core ./rmm-rust
    python -m pip install numpy==2.4.2 networkx==3.6.1 torch==2.10.0 datasets==5.0.0 sentence-transformers==5.2.3 spacy==3.8.14 scipy==1.17.1 transformers==5.3.0
    python -m spacy download en_core_web_sm
    python eval/paper_eval.py --sample prefix --out rerun-prefix.json
    python eval/paper_eval.py --sample balanced --out rerun-balanced.json

The recorded spaCy English model is version 3.8.0. The script pins the embedding and dataset revisions and uses a CPU. It also accepts --arrow PATH for an equivalent locally cached MuSiQue validation Arrow file. The recorded file's SHA-256 and key dependency versions are in the result. Libraries, floating-point reductions and parallel graph operations can affect exact-score ordering across installations.

The script imports construction, embedding and scoring helpers from eval/run_eval.py. Use paper_eval.py for the manuscript protocol. The earlier harness evaluates several cutoffs in sequence on a mutable mesh. The manuscript protocol queries each freshly built mesh once. It measures the tie-breaking variant on the very same activated nodes returned by the entity-graph query.

The paper's reported intervals resample paired question-level differences 10,000 times with NumPy seed 20261119. They quantify variability across these questions for this run. No inference on open-corpus performance or answer generation is intended.

## Applications replay

Run python review_queue.py to reproduce the optional related-passages comparison on the balanced sample. The script also accepts --arrow for a local validation file. It takes the union of the cosine and native entity-RMM top fives, then compares it with a cosine list of exactly the same length for each question. review_queue_results.json records the totals. Gained supports are counted relative to the original five cosine hits; complete counts questions with every annotated supporting paragraph present.
